# Class 3

## Formatting strings
 - curly brace / backticks ``
 var item = 5;
 var sentence = ` I have ${item} candies.``;

 - concatenation - single quotes
 var name = 'Monika';
 var sentence = 'May name is' + name;

var book = 'Javascript'
var sentence = 'I am reading, the book on \'' + book + '\';

- concatenation - double quotes
 var name = "Monika";
 var sentence = "My name is" + name;